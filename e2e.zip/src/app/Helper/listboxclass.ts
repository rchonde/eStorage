import { Injectable } from '@angular/core';
@Injectable()
export class Listboxclass {
    id: number;
    BranchName: string;
    ischecked: boolean;
}
